﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L3z1
{
    internal class Class1
    {
        public static void Moja()
        {
            MessageBox.Show("BUM");
        }
    }
}
